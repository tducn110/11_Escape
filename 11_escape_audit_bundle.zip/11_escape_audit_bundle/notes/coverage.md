# Coverage Notes

Confirmed from workspace:

- current git status
- branch history and commit SHAs
- diff stat and full patch for `bd5c16a`
- spec files under `doc/goal`
- repomix snapshot
- generated reports under `reports/`
- raw rerun outputs for `typecheck`, `test`, `build`, and level CLI commands

Not available in workspace:

- original agent transcript
- pre-run git status snapshot
- original command logs from the first execution window

