# Audit Bundle

Source repo: `/home/pro/Downloads/intern/11_Escape`

Included:

- `spec/goal/` from `doc/goal`
- `repomix/repomix-output.xml`
- `git/` metadata, diff, patch, and commit info
- `reports/` generated report artifacts
- `raw_outputs/` command output captures
- `notes/coverage.md` for unavailable inputs and caveats

Unavailable from workspace:

- full agent transcript/completion report
- git status before the agent started
- raw outputs from the original run at the time they were first produced

